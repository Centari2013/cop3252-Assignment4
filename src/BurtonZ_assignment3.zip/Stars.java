public class Stars {
    int rows, columns;

    void setRows(int r){
        rows = r;
    }

    void setColumns(int c){
        columns = c;
    }
}