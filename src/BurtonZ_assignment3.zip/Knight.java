public class Knight {
    String name;
    int health, age, gold, battles;

    void setName(String n){
        name = n;
    }
    String getName(){
        return name;
    }

    void setHealth(int h){
        health = h;
    }
    int getHealth(){
        return health;
    }

    void setAge(int a){
        age = a;
    }
    int getAge(){
        return age;
    }

    void setGold(int g){
        gold = g;
    }
    int getGold(){
        return gold;
    }

    void setBattles(int b){
        battles = b;
    }
    int getBattles(){
        return battles;
    }
}
